let tolerance = 5;
let d = 10;
let firstPx;

// color to look for (set with mouse click)
let colorToMatch;
let intersecato = false;
let video;

let rectX = 100; // coordinata x del rettangolo
let rectY = 100; // coordinata y del rettangolo
let rectW = 50; // larghezza del rettangolo
let rectH = 75;
let rectX2 = 160; // coordinata x del rettangolo
let rectY2 = 100; // coordinata y del rettangolo
let rectW2 = 50; // larghezza del rettangolo
let rectH2 = 75;
let x = 0;
let y = 0;

function setup() {
  createCanvas(1024, 960);

  // an initial color to look for
  colorToMatch = [255, 0, 0];

  // webcam capture
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();
}

function draw() {
  // Inverto l'immagine orizzontalmente
  let flippedVideo = createImage(video.width, video.height);
  flippedVideo.loadPixels();
  video.loadPixels();
  for (let y = 0; y < video.height; y++) {
    for (let x = 0; x < video.width; x++) {
      let index = (x + y * video.width) * 4;
      let flippedIndex = ((video.width - x - 1) + y * video.width) * 4;
      flippedVideo.pixels[flippedIndex] = video.pixels[index];
      flippedVideo.pixels[flippedIndex + 1] = video.pixels[index + 1];
      flippedVideo.pixels[flippedIndex + 2] = video.pixels[index + 2];
      flippedVideo.pixels[flippedIndex + 3] = video.pixels[index + 3];
      
    }
  }
  flippedVideo.updatePixels();
  // Disegna l'immagine invertita
  image(flippedVideo, 0, 0);
  rect(rectX, rectY, rectW, rectH);
  rect(rectX2, rectY2, rectW2, rectH2);
  firstPx = findColor(video, colorToMatch, tolerance);
  if (firstPx != undefined) {
    let centerX = firstPx.x + d/2;
    let centerY = firstPx.y + d/2;
    fill(colorToMatch);
    stroke(255);
    strokeWeight(2);
    circle(centerX, centerY, d);
    if (firstPx.x + d > rectX && firstPx.x - d < rectX + rectW && firstPx.y + d > rectY && firstPx.y - d < rectY + rectH) {
      console.log('toccato 1');
    }  
    if (firstPx.x + d > rectX2 && firstPx.x - d < rectX2 + rectW2 && firstPx.y + d > rectY2 && firstPx.y - d < rectY2 + rectH2) {
      console.log('toccato 2');
    } 
  }else{
    firstPx = createVector(x, y);
  }
  
}


// use the mouse to select a color to track
function mousePressed() {
  loadPixels();
  colorToMatch = get(mouseX, mouseY);

  // note we use get() here, which is probably
  // ok since it's one pixel – could def do this
  // with pixels[index] too
}


// find the first instance of a color 
// in an image and return the location
function findColor(input, c, tolerance) {

  // if we don't have video yet (ie the sketch
  // just started), then return undefined
  if (input.width === 0 || input.height === 0) {
    return undefined;
  }

  // grab rgb from color to match
  let matchR = c[0];
  let matchG = c[1];
  let matchB = c[2];

  // look for the color!
  // in this case, we look across each row 
  // working our way down the image – depending 
  // on your project, you might want to scan 
  // across instead
  input.loadPixels();
  for (let y=0; y<input.height; y++) {
    for (let x=0; x<input.width; x++) {
 
      // current pixel color
      let index = (y * video.width - x) * 4;
      let r = video.pixels[index];
      let g = video.pixels[index+1];
      let b = video.pixels[index+2];

      // if our color detection has no wiggle-room 
      // (either the color matches perfectly or isn't 
      // seen at all) then it won't work very well in 
      // real-world conditions to overcome this, we 
      // check if the rgb values are within a certain 
      // range – if they are, we consider it a match
      if (r >= matchR-tolerance && r <= matchR+tolerance &&
          g >= matchG-tolerance && g <= matchG+tolerance &&
          b >= matchB-tolerance && b <= matchB+tolerance) {

          // send back the x/y location immediately
          // (faster, since we stop the loop)
          return createVector(x, y);
      }
    }
  }

  // if no match was found, return 'undefined'
  //return undefined;
}

